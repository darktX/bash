#!/bin/bash
x="Jacek Papis"
echo $x
