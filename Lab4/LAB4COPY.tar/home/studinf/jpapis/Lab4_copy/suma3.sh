#!/bin/bash
zmienna1=2
zmienna2=3
zmienna3=5
echo $[$zmienna1+$zmienna2+$zmienna3]
