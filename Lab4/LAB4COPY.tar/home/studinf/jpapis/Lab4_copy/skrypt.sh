#!/bin/bash
#Tu jest komentarz.
echo "Hello world"
