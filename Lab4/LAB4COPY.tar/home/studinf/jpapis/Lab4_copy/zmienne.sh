#!/bin/bash
x=68
y="tresc napisu"
echo $x
echo $y
