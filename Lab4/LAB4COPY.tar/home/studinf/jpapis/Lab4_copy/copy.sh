#!/bin/bash
mkdir ~/Lab4_copy/
cp -R ~/Lab4/. ~/Lab4_copy/
