#!/bin/bash
x=`who | wc -l`
echo $x
