#!/bin/bash

echo $[12345+98765]
